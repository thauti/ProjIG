package View;

import javafx.event.EventHandler;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import Controller.*;

public class View extends Pane{


	public View()
	{
		super(); this.setFocusTraversable(true);
	}
	public void update()
	{
	}

}

