package Controller;


import Model.*;
import View.*;

public class MapController extends Controller{
    public MapController() {
        super(new MapModel(), new MapView());


    }
}
