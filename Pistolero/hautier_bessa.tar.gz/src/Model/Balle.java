package Model;

public class Balle extends Model {
}
