package Model;

import Controller.VampireController;

import java.util.ArrayList;

public class Model {

	
	
}
